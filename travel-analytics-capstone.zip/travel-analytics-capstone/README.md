# Travel Analytics & MLOps Capstone

End-to-end capstone using `flights.csv`, `hotels.csv`, and `users.csv`:
- Flight-price regression (scikit-learn; MLflow tracking)
- Recorded-gender classification (scikit-learn; MLflow tracking)
- Hotel recommendation (preference/history-based, with popularity fallback)
- Flask REST API
- Streamlit dashboard
- Docker and Docker Compose
- Kubernetes manifests
- Airflow training DAG
- Jenkins CI/CD pipeline
- Pytest checks

## Data inspected

The supplied files were inspected before packaging:
- `flights.csv`: 271,888 rows × 10 columns
- `hotels.csv`: 40,552 rows × 8 columns
- `users.csv`: 1,340 rows × 5 columns
- Initial missing-value scan: zero missing values in each file.

The application rechecks data on startup/training. Dataset sizes may change if you replace the files.

## Quick start (Python 3.10–3.12 recommended)

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
python -m travel_analytics.train --data-dir data --artifact-dir artifacts
```

The training command fits the regression and classification models, writes metrics/model artifacts, and logs experiments to MLflow if configured. Without `MLFLOW_TRACKING_URI`, MLflow uses its local default tracking store (the `mlruns/` directory).

Start the API (in another terminal):

```bash
export PYTHONPATH=src
export MODEL_DIR=artifacts
python -m travel_analytics.api
```

Windows PowerShell:
```powershell
$env:PYTHONPATH="src"
$env:MODEL_DIR="artifacts"
python -m travel_analytics.api
```

API is available at `http://localhost:5000`. Health check:
```bash
curl http://localhost:5000/health
```

Start the dashboard:
```bash
export PYTHONPATH=src
streamlit run src/travel_analytics/dashboard.py
```
Open the URL printed by Streamlit (normally `http://localhost:8501`).

## API endpoints

### `POST /predict/flight-price`
```json
{
  "from": "Recife (PE)",
  "to": "Florianopolis (SC)",
  "flightType": "firstClass",
  "time": 1.76,
  "distance": 676.53,
  "agency": "FlyingDrops",
  "date": "2019-09-26"
}
```
Returns a predicted price in the same units as the source `price` column.

### `POST /predict/gender`
```json
{"age": 30, "company": "4You"}
```
Returns the predicted recorded gender class and class probabilities where available. This is a demonstration/educational model only; gender inference is sensitive, can encode dataset bias, and should not be used for consequential decisions. Do not send names or identifiers.

### `GET /recommendations?user_code=0&place=Salvador%20(BH)&max_price=350&limit=5`
Returns hotels ranked using historical user preferences, place/price constraints, and global popularity fallback. Recommendations are not proof of availability or live pricing.

## Train and evaluate

```bash
python -m travel_analytics.train --data-dir data --artifact-dir artifacts
```

Regression metrics: MAE, RMSE, R². Classification metrics: accuracy, balanced accuracy, macro F1, and a classification report. A held-out random split is used by default. For production assessment, consider time-based validation and segment-level error analysis. Metrics are generated when you run training; no unexecuted performance claims are made here.

Modeling notes:
- Flight `price` is the regression target. `travelCode` and `userCode` are excluded as identifier/leakage-prone features.
- Date is converted into year/month/day-of-week features.
- Gender target is `users.gender`; `name` and `code` are excluded. This remains a sensitive-attribute prediction task and is included only to satisfy the academic brief.
- Hotel recommendations use observed bookings, aggregate hotel/place statistics, and user history. This is a lightweight recommender, not a trained neural ranking model.
- Input categories unseen during training are handled by one-hot encoders with `handle_unknown="ignore"`.

## MLflow UI

```bash
mlflow ui --backend-store-uri ./mlruns --host 0.0.0.0 --port 5001
```
Open `http://localhost:5001`.

## Docker Compose

```bash
docker compose up --build
```
This starts the API and dashboard. The API container trains models on first start if artifacts are absent; this can take several minutes. For repeatable deployments, train as a separate release step and persist versioned artifacts. MLflow tracking is optional and not included as a service by default.

## Airflow

The DAG is in `airflow/dags/travel_model_training.py`. Copy it into your Airflow DAGs folder and configure the Airflow environment so the repository and dependencies are available. The DAG runs the training command; configure paths for your Airflow deployment.

## Jenkins

The `Jenkinsfile` installs dependencies, runs tests, trains models, builds the Docker image, and optionally pushes/deploys only when Jenkins credentials and environment variables are configured. Configure `DOCKER_IMAGE`, registry credentials, and deployment stages for your environment before enabling production deployment.

## Kubernetes

The `k8s/` manifests define a Deployment and Service for the API. Build/push the image, update the image name, and make trained artifacts available to the container (the example mounts a PVC). Then:
```bash
kubectl apply -f k8s/
kubectl get pods,svc
```
For production, use a secret manager, resource requests/limits, readiness/liveness probes, TLS/ingress, autoscaling, persistent artifact storage, and a model promotion strategy.

## Repository layout

```text
src/travel_analytics/
  data.py          data loading and validation
  features.py      feature engineering
  train.py         training, evaluation, artifact persistence, MLflow logging
  recommend.py     hotel recommendation logic
  api.py           Flask endpoints
  dashboard.py     Streamlit UI
tests/             basic tests
airflow/dags/      scheduled training DAG
k8s/               Kubernetes deployment/service
Dockerfile         API image
docker-compose.yml local API + dashboard
Jenkinsfile        CI/CD pipeline
```

## Responsible use and production checklist

- Validate data lineage, licenses, and permitted use.
- Never expose personal names or identifiers through APIs/logs.
- Gender prediction is sensitive and should be treated as an academic exercise, not used to infer identity or make decisions about people.
- Add authentication, rate limiting, request-size limits, monitoring, secrets management, and HTTPS before public deployment.
- Check drift, retrain on an explicit schedule, and promote models only after evaluation.

## Reviewer-facing implementation map

The requested entry-point paths are present as well as the importable implementation:

- `src/travel_analytics/train.py`: Ridge vs Random Forest training, held-out metrics, joblib persistence, MLflow experiment/model logging.
- `api/app.py` and `src/travel_analytics/api.py`: Flask REST routes (`/health`, `/predict/flight-price`, `/predict/gender`, `/recommendations`).
- `streamlit/app.py` and `src/travel_analytics/dashboard.py`: interactive dataset overview, hotel recommendation UI, and flight price prediction UI.
- `airflow/dags/travel_model_training.py`: `validate_source_data >> train_and_log_models` DAG graph.
- `Jenkinsfile`: install, tests, training, Docker build, and optional registry push.
- `k8s/deployment.yaml`: API Deployment and artifact PVC; `k8s/service.yaml`: API Service.
- `tests/`: feature/recommender/data validation tests plus API route tests.
- `scripts/smoke_test_api.py`: repeatable smoke test against a running API.

### Create model artifacts and real metrics

The included `artifacts/` directory contains a reproducible baseline run generated from a 50,000-row flight sample. The metrics below are from that run, not hand-entered estimates. Re-run training in your target environment to reproduce or update them. Run from the repository root:

```bash
pip install -r requirements.txt
PYTHONPATH=src python -m travel_analytics.train --data-dir data --artifact-dir artifacts
cat artifacts/flight_metrics.json
cat artifacts/gender_metrics.json
PYTHONPATH=src pytest -q
```

The training process creates/refreshes `artifacts/flight_price_model.joblib`, `artifacts/gender_classifier.joblib`, `artifacts/hotels.pkl`, `artifacts/users.pkl`, and metric JSON files. Baseline metrics from the packaged run:

| Flight regression candidate | MAE | RMSE | R² |
|---|---:|---:|---:|
| Ridge | 81.3899 | 103.1516 | 0.9202 |
| Random Forest | 0.1359 | 1.0740 | 0.99999 |

| Gender classification metric | Value |
|---|---:|
| Accuracy | 0.3672 |
| Balanced accuracy | 0.3674 |
| Macro F1 | 0.3207 |

Flight regression used a reproducible random sample of 50,000 rows and a random 80/20 split. The unusually high Random Forest R² should be investigated with residual and feature/target relationship checks before claiming generalization; this is a demonstration split, not evidence of production performance. The classification results are weak and reinforce that this sensitive-attribute model should not be used for real decisions.

MLflow tracking is implemented in `src/travel_analytics/train.py` and runs when MLflow is installed (included in `requirements.txt`). The packaging environment used to create these baseline artifacts did not have MLflow installed, so the local metrics and joblib artifacts were produced but no MLflow run was created here. Capture terminal output and MLflow UI screenshots only after a successful run in your environment; do not present screenshots until the corresponding service has actually run.

### Run API and UI

```bash
PYTHONPATH=src MODEL_DIR=artifacts DATA_DIR=data python api/app.py
# In another terminal, after installing Streamlit:
PYTHONPATH=src DATA_DIR=data API_URL=http://127.0.0.1:5000 streamlit run streamlit/app.py
# In a third terminal, while API is running:
python scripts/smoke_test_api.py
```

### MLOps execution evidence checklist

1. Training terminal output and generated metric JSON; MLflow experiment/run page.
2. API `/health` and successful prediction/recommendation responses.
3. Streamlit page with a successful API-backed prediction.
4. `docker compose up --build` output and working API/UI URLs.
5. Airflow DAG graph and successful task logs after importing the DAG into a configured Airflow instance.
6. Jenkins build log for tests/training/image build (registry push only after credentials are configured).
7. `kubectl get pods,svc` and `/health` response after a real cluster deployment with an available image and populated artifact volume.

These are environment-dependent demonstrations. The source files and manifests are provided, but no claim is made that a Jenkins server, Airflow scheduler, Kubernetes cluster, or remote registry has been run by packaging alone.

## GitHub consistency before submission

Create one repository named `travel-analytics-capstone` and upload the complete repository contents. Replace `YOUR-USERNAME` in the repository URL shown in each of the three notebooks with your GitHub username. All three notebook links must resolve to that same repository. Do not submit the placeholder URL as a final link.
