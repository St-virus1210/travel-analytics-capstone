import os
import requests
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
from pathlib import Path

st.set_page_config(page_title="Travel Analytics", page_icon="✈️", layout="wide")
st.title("✈️ Travel Analytics & Recommendations")
st.caption("Exploration and hotel recommendations from the supplied travel datasets.")
data_dir = Path(os.getenv("DATA_DIR", "data"))
api_url = os.getenv("API_URL", "http://localhost:5000")

@st.cache_data
def read_csv(name):
    return pd.read_csv(data_dir / name)

try:
    flights, hotels, users = read_csv("flights.csv"), read_csv("hotels.csv"), read_csv("users.csv")
except Exception as exc:
    st.error(f"Could not load CSV files from {data_dir.resolve()}: {exc}")
    st.stop()

tab1, tab2, tab3 = st.tabs(["Overview", "Hotel recommendations", "Flight price prediction"])
with tab1:
    c1, c2, c3 = st.columns(3)
    c1.metric("Flight records", f"{len(flights):,}")
    c2.metric("Hotel bookings", f"{len(hotels):,}")
    c3.metric("Users", f"{len(users):,}")
    st.subheader("Flight price distribution")
    fig, ax = plt.subplots()
    flights["price"].clip(upper=flights["price"].quantile(0.99)).hist(bins=40, ax=ax)
    ax.set_xlabel("Flight price (99th percentile clipped for display)")
    ax.set_ylabel("Records")
    st.pyplot(fig)
    st.subheader("Most frequently booked hotel locations")
    top_places = hotels["place"].value_counts().head(10)
    st.bar_chart(top_places)
    st.subheader("Average hotel price per day by location")
    st.dataframe(hotels.groupby("place", as_index=False)["price"].mean().sort_values("price").rename(columns={"price":"avg_price_per_day"}), use_container_width=True)

with tab2:
    st.write("Recommendations are based on historical booking frequency, relative price, and optional user booking history.")
    user_code = st.number_input("User code (optional; enter -1 for popularity only)", min_value=-1, value=0, step=1)
    places = ["Any"] + sorted(hotels["place"].dropna().astype(str).unique().tolist())
    place = st.selectbox("Destination", places)
    max_price = st.number_input("Maximum price per day (0 = no limit)", min_value=0.0, value=0.0, step=25.0)
    limit = st.slider("Number of recommendations", 1, 20, 5)
    if st.button("Get recommendations"):
        params = {"limit": limit}
        if user_code >= 0: params["user_code"] = int(user_code)
        if place != "Any": params["place"] = place
        if max_price > 0: params["max_price"] = max_price
        try:
            response = requests.get(f"{api_url}/recommendations", params=params, timeout=20)
            response.raise_for_status()
            recs = response.json()["recommendations"]
            if recs: st.dataframe(pd.DataFrame(recs), use_container_width=True)
            else: st.info("No matching hotels. Try removing a filter.")
        except requests.RequestException as exc:
            st.error(f"API unavailable ({exc}). Start the Flask API and train/persist artifacts first.")

with tab3:
    st.write("Enter route attributes to request a price estimate from the trained regression model.")
    col1, col2 = st.columns(2)
    origins = sorted(flights["from"].dropna().astype(str).unique())
    destinations = sorted(flights["to"].dropna().astype(str).unique())
    agencies = sorted(flights["agency"].dropna().astype(str).unique())
    types = sorted(flights["flightType"].dropna().astype(str).unique())
    with col1:
        origin = st.selectbox("Origin", origins)
        destination = st.selectbox("Destination", destinations)
        flight_type = st.selectbox("Flight type", types)
        agency = st.selectbox("Agency", agencies)
    with col2:
        duration = st.number_input("Duration", min_value=0.0, value=float(flights["time"].median()))
        distance = st.number_input("Distance", min_value=0.0, value=float(flights["distance"].median()))
        travel_date = st.date_input("Travel date")
    if st.button("Predict flight price"):
        payload = {"from": origin, "to": destination, "flightType": flight_type, "agency": agency,
                   "time": duration, "distance": distance, "date": travel_date.isoformat()}
        try:
            response = requests.post(f"{api_url}/predict/flight-price", json=payload, timeout=30)
            response.raise_for_status()
            st.success(f"Predicted price: {response.json()['predicted_price']:.2f} (source dataset units)")
        except requests.RequestException as exc:
            st.error(f"Prediction API unavailable ({exc}). Train models and start the API first.")
