import argparse
import json
import os
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
try:
    import mlflow
    import mlflow.sklearn
    MLFLOW_AVAILABLE = True
except ImportError:  # Allow local model training where optional experiment tracking is unavailable.
    from contextlib import contextmanager
    MLFLOW_AVAILABLE = False

    class _NoopRun:
        def __enter__(self): return self
        def __exit__(self, *_): return False

    class _NoopMLflow:
        def set_experiment(self, *_args, **_kwargs): pass
        def start_run(self, *_args, **_kwargs): return _NoopRun()
        def log_param(self, *_args, **_kwargs): pass
        def log_metrics(self, *_args, **_kwargs): pass
        def log_text(self, *_args, **_kwargs): pass

    class _NoopSklearn:
        def log_model(self, *_args, **_kwargs): pass

    mlflow = _NoopMLflow()
    mlflow.sklearn = _NoopSklearn()
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor, RandomForestClassifier
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score, accuracy_score, balanced_accuracy_score, f1_score, classification_report
from travel_analytics.data import load_data
from travel_analytics.features import FLIGHT_CATEGORICAL, FLIGHT_NUMERIC, FLIGHT_FEATURES, flight_features, user_features

def build_flight_pipeline(model_name="random_forest"):
    prep = ColumnTransformer([
        ("cat", Pipeline([("imputer", SimpleImputer(strategy="most_frequent")),
                          ("onehot", OneHotEncoder(handle_unknown="ignore", min_frequency=2))]), FLIGHT_CATEGORICAL),
        ("num", Pipeline([("imputer", SimpleImputer(strategy="median")), ("scale", StandardScaler())]), FLIGHT_NUMERIC),
    ])
    model = RandomForestRegressor(n_estimators=80, min_samples_leaf=2, max_depth=24, random_state=42, n_jobs=-1) if model_name == "random_forest" else Ridge(alpha=2.0)
    return Pipeline([("preprocess", prep), ("model", model)])

def build_gender_pipeline():
    prep = ColumnTransformer([
        ("cat", OneHotEncoder(handle_unknown="ignore"), ["company"]),
        ("num", Pipeline([("imputer", SimpleImputer(strategy="median")), ("scale", StandardScaler())]), ["age"]),
    ])
    return Pipeline([("preprocess", prep), ("model", LogisticRegression(max_iter=1500, class_weight="balanced"))])

def _rmse(y_true, y_pred):
    return float(np.sqrt(mean_squared_error(y_true, y_pred)))

def train(data_dir="data", artifact_dir="artifacts"):
    data = load_data(data_dir)
    out = Path(artifact_dir)
    out.mkdir(parents=True, exist_ok=True)
    if MLFLOW_AVAILABLE:
        mlflow.set_experiment("travel-analytics-capstone")
    else:
        print("MLflow is not installed; training and local metrics will still run, but experiment tracking is skipped.")

    flights = data["flights"].copy()
    # Bound local/CI training time while preserving reproducibility. Set MAX_FLIGHT_ROWS=0 to use all rows.
    max_rows = int(os.getenv("MAX_FLIGHT_ROWS", "50000"))
    if max_rows > 0 and len(flights) > max_rows:
        flights = flights.sample(n=max_rows, random_state=42)
        print(f"Training flight models on a reproducible sample of {max_rows:,} rows (set MAX_FLIGHT_ROWS=0 to use all rows).")
    flights["price"] = pd.to_numeric(flights["price"], errors="coerce")
    flights = flights.dropna(subset=["price"])
    X = flight_features(flights)
    y = flights["price"].astype(float)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    candidates = {"ridge": build_flight_pipeline("ridge"), "random_forest": build_flight_pipeline("random_forest")}
    best = None
    best_mae = float("inf")
    regression_metrics = {}
    for name, model in candidates.items():
        with mlflow.start_run(run_name=f"flight-regression-{name}") as run:
            model.fit(X_train, y_train)
            pred = model.predict(X_test)
            metrics = {"mae": float(mean_absolute_error(y_test, pred)), "rmse": _rmse(y_test, pred), "r2": float(r2_score(y_test, pred))}
            mlflow.log_param("model", name)
            mlflow.log_param("test_size", 0.2)
            mlflow.log_param("training_rows", len(X_train))
            mlflow.log_param("test_rows", len(X_test))
            mlflow.log_metrics(metrics)
            mlflow.sklearn.log_model(model, artifact_path="model")
            regression_metrics[name] = metrics
            if metrics["mae"] < best_mae:
                best_mae, best = metrics["mae"], model
    joblib.dump(best, out / "flight_price_model.joblib")
    with open(out / "flight_metrics.json", "w") as f:
        json.dump({"candidate_metrics": regression_metrics, "selected_model": "lowest_mae"}, f, indent=2)

    users = data["users"].copy()
    users = users.dropna(subset=["gender"])
    users["gender"] = users["gender"].astype(str)
    ux = user_features(users)
    uy = users["gender"]
    if uy.nunique() < 2:
        raise ValueError("Gender classification requires at least two target classes")
    stratify = uy if uy.value_counts().min() >= 2 else None
    ux_train, ux_test, uy_train, uy_test = train_test_split(ux, uy, test_size=0.25, random_state=42, stratify=stratify)
    classifier = build_gender_pipeline()
    with mlflow.start_run(run_name="recorded-gender-classification"):
        classifier.fit(ux_train, uy_train)
        pred = classifier.predict(ux_test)
        metrics = {
            "accuracy": float(accuracy_score(uy_test, pred)),
            "balanced_accuracy": float(balanced_accuracy_score(uy_test, pred)),
            "macro_f1": float(f1_score(uy_test, pred, average="macro", zero_division=0)),
        }
        mlflow.log_param("model", "logistic_regression")
        mlflow.log_metrics(metrics)
        mlflow.log_text(classification_report(uy_test, pred, zero_division=0), "classification_report.txt")
        mlflow.sklearn.log_model(classifier, artifact_path="model")
    joblib.dump(classifier, out / "gender_classifier.joblib")
    with open(out / "gender_metrics.json", "w") as f:
        json.dump({"metrics": metrics, "classification_report": classification_report(uy_test, pred, zero_division=0)}, f, indent=2)

    # Persist the historical tables needed by the recommendation endpoint/dashboard.
    for name in ["hotels", "users"]:
        data[name].to_pickle(out / f"{name}.pkl")
    print(json.dumps({"artifact_dir": str(out), "flight_regression": regression_metrics, "gender_classification": metrics}, indent=2))
    return {"flight_regression": regression_metrics, "gender_classification": metrics}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default="data")
    parser.add_argument("--artifact-dir", default="artifacts")
    args = parser.parse_args()
    train(args.data_dir, args.artifact_dir)

if __name__ == "__main__":
    main()
