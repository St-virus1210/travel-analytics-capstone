import json
import joblib
import pandas as pd
import pytest

flask = pytest.importorskip("flask")
from travel_analytics.api import create_app


def test_health_route_reports_missing_models(tmp_path):
    app = create_app(model_dir=tmp_path, data_dir=tmp_path)
    response = app.test_client().get("/health")
    assert response.status_code == 200
    assert response.get_json()["status"] == "ok"
    assert response.get_json()["models_available"] is False


def test_flight_endpoint_validates_payload(tmp_path):
    app = create_app(model_dir=tmp_path, data_dir=tmp_path)
    response = app.test_client().post("/predict/flight-price", json={"from": "A"})
    assert response.status_code == 400
    assert "fields" in response.get_json()
