import pandas as pd
from travel_analytics.features import flight_features, user_features
from travel_analytics.recommend import recommend_hotels
from travel_analytics.data import validate_data

def test_flight_features():
    frame = pd.DataFrame([{"from":"A","to":"B","flightType":"economy","agency":"X","time":2,"distance":100,"date":"2024-01-01"}])
    X = flight_features(frame)
    assert "date_month" in X.columns
    assert X.iloc[0]["date_year"] == 2024

def test_user_features_excludes_name_and_id():
    frame = pd.DataFrame([{"age":25,"company":"Example","name":"Person","code":123}])
    assert list(user_features(frame).columns) == ["age","company"]

def test_recommender_returns_expected_shape():
    hotels = pd.DataFrame([
        {"travelCode":1,"userCode":7,"name":"Hotel A","place":"City","days":2,"price":100,"total":200},
        {"travelCode":2,"userCode":8,"name":"Hotel A","place":"City","days":3,"price":100,"total":300},
        {"travelCode":3,"userCode":9,"name":"Hotel B","place":"City","days":2,"price":200,"total":400},
    ])
    result = recommend_hotels(hotels, user_code=7, limit=2)
    assert len(result) == 2
    assert all("average_price_per_day" in r for r in result)

def test_validation():
    data = {
      "flights": pd.DataFrame(columns=["travelCode","userCode","from","to","flightType","price","time","distance","agency","date"]),
      "hotels": pd.DataFrame(columns=["travelCode","userCode","name","place","days","price","total","date"]),
      "users": pd.DataFrame(columns=["code","company","name","gender","age"])
    }
    try:
        validate_data(data)
        assert False, "empty datasets should fail"
    except ValueError:
        assert True
