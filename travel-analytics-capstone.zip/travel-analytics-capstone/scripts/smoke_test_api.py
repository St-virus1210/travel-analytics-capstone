"""Smoke-test a running API. Start it after training models; then run this script."""
import os
import requests

BASE_URL = os.getenv("API_URL", "http://127.0.0.1:5000")
health = requests.get(f"{BASE_URL}/health", timeout=10)
health.raise_for_status()
print("GET /health:", health.json())
if not health.json().get("models_available"):
    raise SystemExit("Models are not available; run the training command first.")
payload = {
    "from": "Recife (PE)", "to": "Florianopolis (SC)",
    "flightType": "firstClass", "time": 1.76, "distance": 676.53,
    "agency": "FlyingDrops", "date": "2019-09-26",
}
response = requests.post(f"{BASE_URL}/predict/flight-price", json=payload, timeout=30)
response.raise_for_status()
print("POST /predict/flight-price:", response.json())
recommendations = requests.get(f"{BASE_URL}/recommendations", params={"limit": 5}, timeout=20)
recommendations.raise_for_status()
print("GET /recommendations:", recommendations.json())
