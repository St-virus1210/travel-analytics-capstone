import os
from pathlib import Path
import joblib
import pandas as pd
from flask import Flask, jsonify, request
from travel_analytics.features import flight_features, user_features
from travel_analytics.recommend import load_recommendation_data, recommend_hotels

def create_app(model_dir=None, data_dir=None):
    app = Flask(__name__)
    model_dir = Path(model_dir or os.getenv("MODEL_DIR", "artifacts"))
    data_dir = data_dir or os.getenv("DATA_DIR", "data")

    def model(name):
        path = model_dir / name
        if not path.exists():
            raise FileNotFoundError(f"Model artifact not found: {path}. Run training first.")
        return joblib.load(path)

    @app.get("/health")
    def health():
        return jsonify({"status": "ok", "models_available": (model_dir/"flight_price_model.joblib").exists() and (model_dir/"gender_classifier.joblib").exists()})

    @app.post("/predict/flight-price")
    def predict_flight_price():
        payload = request.get_json(silent=True)
        if not isinstance(payload, dict):
            return jsonify({"error": "Request body must be a JSON object"}), 400
        required = ["from", "to", "flightType", "time", "distance", "agency", "date"]
        missing = [k for k in required if k not in payload]
        if missing:
            return jsonify({"error": "Missing required fields", "fields": missing}), 400
        try:
            X = flight_features(pd.DataFrame([payload]))
            prediction = float(model("flight_price_model.joblib").predict(X)[0])
            return jsonify({"predicted_price": round(prediction, 2), "currency": "dataset_units", "note": "Currency is not specified in the source dataset."})
        except (ValueError, TypeError) as exc:
            return jsonify({"error": str(exc)}), 400
        except FileNotFoundError as exc:
            return jsonify({"error": str(exc)}), 503

    @app.post("/predict/gender")
    def predict_gender():
        payload = request.get_json(silent=True)
        if not isinstance(payload, dict):
            return jsonify({"error": "Request body must be a JSON object"}), 400
        if "age" not in payload or "company" not in payload:
            return jsonify({"error": "Required fields: age, company"}), 400
        try:
            X = user_features(pd.DataFrame([payload]))
            clf = model("gender_classifier.joblib")
            predicted = str(clf.predict(X)[0])
            probs = {}
            if hasattr(clf, "predict_proba"):
                probs = {str(k): round(float(v), 4) for k, v in zip(clf.classes_, clf.predict_proba(X)[0])}
            return jsonify({"predicted_recorded_gender": predicted, "class_probabilities": probs,
                            "warning": "Sensitive attribute inference; academic demonstration only, not for decisions about people."})
        except (ValueError, TypeError) as exc:
            return jsonify({"error": str(exc)}), 400
        except FileNotFoundError as exc:
            return jsonify({"error": str(exc)}), 503

    @app.get("/recommendations")
    def recommendations():
        try:
            hotels, _ = load_recommendation_data(model_dir, data_dir)
            results = recommend_hotels(
                hotels,
                user_code=request.args.get("user_code"),
                place=request.args.get("place"),
                max_price=request.args.get("max_price", type=float),
                limit=request.args.get("limit", default=5, type=int),
            )
            return jsonify({"recommendations": results, "count": len(results)})
        except (ValueError, TypeError) as exc:
            return jsonify({"error": str(exc)}), 400

    @app.errorhandler(500)
    def server_error(_):
        return jsonify({"error": "Internal server error"}), 500
    return app

app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=False)
